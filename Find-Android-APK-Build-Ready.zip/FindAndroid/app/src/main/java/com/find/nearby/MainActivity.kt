package com.find.nearby

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat

private val Black = Color(0xFF101010)
private val Panel = Color(0xFF201C14)
private val Gold = Color(0xFFE5B84B)
private val Cream = Color(0xFFF2E8D2)

class MainActivity : ComponentActivity() {
    private val foundDevices = mutableStateListOf<String>()
    private var scanMessage by mutableStateOf("Demo mode — no Find users detected yet")
    private var scanning by mutableStateOf(false)

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
            if (grants.values.all { it }) startFindScan()
            else scanMessage = "Bluetooth permission was not granted."
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            FindApp(
                devices = foundDevices.toList(),
                scanMessage = scanMessage,
                scanning = scanning,
                onScan = { requestScanPermissions() }
            )
        }
    }

    private fun requestScanPermissions() {
        val needed = if (Build.VERSION.SDK_INT >= 31) {
            arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        } else {
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        val missing = needed.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) startFindScan()
        else permissionLauncher.launch(missing.toTypedArray())
    }

    @Suppress("MissingPermission")
    private fun startFindScan() {
        val manager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        val adapter: BluetoothAdapter? = manager.adapter
        if (adapter == null || !adapter.isEnabled) {
            scanMessage = "Turn on Bluetooth to scan for nearby devices."
            return
        }
        val scanner = adapter.bluetoothLeScanner
        if (scanner == null) {
            scanMessage = "Bluetooth LE scanning is unavailable on this device."
            return
        }
        foundDevices.clear()
        scanning = true
        scanMessage = "Scanning nearby Bluetooth advertisements. This does not identify WhatsApp accounts."
        scanner.startScan(object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                // Only display a device if it explicitly advertises the Find service name.
                val name = result.scanRecord?.deviceName ?: return
                if (name.startsWith("FIND-") && name !in foundDevices) {
                    foundDevices.add(name)
                }
            }
            override fun onScanFailed(errorCode: Int) {
                scanning = false
                scanMessage = "Bluetooth scan failed (code $errorCode)."
            }
        })
        window.decorView.postDelayed({
            try { scanner.stopScan(object : ScanCallback() {}) } catch (_: Exception) {}
            scanning = false
            if (foundDevices.isEmpty()) {
                scanMessage = "No Find-enabled devices found. Other people must opt in and broadcast a Find signal."
            } else {
                scanMessage = "Find-enabled signals detected. Contact details are not exposed by Bluetooth."
            }
        }, 10_000)
    }
}

@Composable
private fun FindApp(
    devices: List<String>,
    scanMessage: String,
    scanning: Boolean,
    onScan: () -> Unit
) {
    var tab by remember { mutableStateOf("Nearby") }
    var visible by remember { mutableStateOf(false) }
    var radius by remember { mutableStateOf("100 m") }
    var chatText by remember { mutableStateOf("") }
    var messages by remember { mutableStateOf(listOf("Welcome to Find. Chat becomes available after both people accept a request.")) }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Black, surface = Panel, primary = Gold,
        onPrimary = Black, onBackground = Cream, onSurface = Cream
    )) {
        Scaffold(containerColor = Black, bottomBar = {
            NavigationBar(containerColor = Panel) {
                listOf("Nearby", "Chat", "Profile").forEach { item ->
                    NavigationBarItem(
                        selected = tab == item,
                        onClick = { tab = item },
                        icon = {
                            Icon(
                                when (item) {
                                    "Nearby" -> Icons.Default.Explore
                                    "Chat" -> Icons.Default.Chat
                                    else -> Icons.Default.Person
                                }, contentDescription = item
                            )
                        },
                        label = { Text(item) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Gold, selectedTextColor = Gold,
                            indicatorColor = Color(0xFF44371D),
                            unselectedIconColor = Cream, unselectedTextColor = Cream
                        )
                    )
                }
            }
        }) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Explore, null, tint = Gold, modifier = Modifier.size(34.dp))
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text("FIND", style = MaterialTheme.typography.headlineLarge, color = Gold)
                        Text("CONNECT NEAR YOU", style = MaterialTheme.typography.labelSmall, color = Cream)
                    }
                }
                when (tab) {
                    "Nearby" -> {
                        Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text("Nearby discovery", color = Gold, style = MaterialTheme.typography.titleLarge)
                                Text("Discovery radius")
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf("50 m", "100 m", "250 m", "500 m").forEach {
                                        FilterChip(selected = radius == it, onClick = { radius = it }, label = { Text(it) })
                                    }
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Switch(checked = visible, onCheckedChange = { visible = it })
                                    Spacer(Modifier.width(8.dp))
                                    Text("Allow my profile to be discoverable")
                                }
                                Text("Visibility is a preference only in this starter build; server-side discovery is not connected.",
                                    style = MaterialTheme.typography.bodySmall, color = Cream)
                            }
                        }
                        Button(onClick = onScan, modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Gold)) {
                            Icon(Icons.Default.Bluetooth, null)
                            Spacer(Modifier.width(8.dp))
                            Text(if (scanning) "Scanning…" else "Scan nearby Bluetooth")
                        }
                        Text(scanMessage, color = Cream, style = MaterialTheme.typography.bodySmall)
                        if (devices.isNotEmpty()) {
                            Text("Find signals", color = Gold, style = MaterialTheme.typography.titleMedium)
                            devices.forEach { Text("• $it", color = Cream) }
                        }
                        Text("No phone numbers, WhatsApp IDs, or private identities are collected from nearby devices.",
                            color = Cream, style = MaterialTheme.typography.bodySmall)
                    }
                    "Chat" -> {
                        Text("Private chat", color = Gold, style = MaterialTheme.typography.titleLarge)
                        Text("Chat is a UI preview. Real messaging needs a secure backend and an accepted chat request.")
                        LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
                            items(messages) { Text(it, Modifier.padding(8.dp).background(Panel, RoundedCornerShape(12.dp)).padding(12.dp), color = Cream) }
                        }
                        OutlinedTextField(value = chatText, onValueChange = { chatText = it },
                            modifier = Modifier.fillMaxWidth(), label = { Text("Demo message") })
                        Button(onClick = {
                            if (chatText.isNotBlank()) {
                                messages = messages + "You: $chatText"
                                chatText = ""
                            }
                        }, colors = ButtonDefaults.buttonColors(containerColor = Gold)) { Text("Add demo message") }
                    }
                    else -> {
                        Text("My profile", color = Gold, style = MaterialTheme.typography.titleLarge)
                        Text("Profile setup and verified account registration will be added with the backend.")
                        Text("Privacy controls", color = Gold)
                        Text("• Discoverable only when you opt in\n• Contact details shared only after approval\n• Block and report controls required before launch")
                    }
                }
            }
        }
    }
}

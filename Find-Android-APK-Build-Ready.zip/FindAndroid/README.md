# Find — Android starter prototype

Black + Gold Android app starter using Kotlin and Jetpack Compose.

## Open
1. Install Android Studio (current stable).
2. Open this folder as an existing Gradle project.
3. Let Gradle sync.
4. Connect an Android phone or start an emulator.
5. Run the `app` configuration.

## What is included
- Black + Gold Compose UI.
- Nearby screen with 50/100/250/500 m radius selector.
- Local discoverability preference toggle (UI only).
- Bluetooth LE scan permission flow.
- Scan displays only BLE advertisements whose device name begins with `FIND-`.
- Chat and profile preview screens.

## Important limitations
This is a starter prototype, not a production-ready app or signed APK.
- A BLE scan cannot discover WhatsApp accounts, phone numbers, or private identities.
- A device must explicitly broadcast a Find-compatible signal to appear. The advertising/broadcast side is not implemented yet.
- Devices that have not installed Find cannot join Find's private discovery/chat network through this app.
- Radius selection is UI-only; BLE signal strength is not a reliable 100 m distance measurement.
- Chat is a local UI preview. Real chat requires a secure backend, user accounts, chat-request acceptance, abuse reporting, and push notifications.
- IP addresses and telecom providers cannot be used to identify nearby subscribers or retrieve their contact details.
- Before release, add a privacy policy, data deletion, rate limits, moderation, and appropriate Android permission disclosures.

## Suggested production architecture
- Android: Kotlin + Jetpack Compose.
- Backend: authenticated API + database + WebSocket messaging.
- Discovery: opt-in Find BLE service advertisement plus server-side online presence.
- Contact exchange: explicit in-app request and acceptance; then open a user-selected messaging app if desired.


## Build an APK using GitHub Actions (no local Android SDK required)
1. Create a new GitHub repository.
2. Upload the contents of this project folder to the repository (including the `.github` folder).
3. Open the repository's **Actions** tab.
4. Run **Build Find Android APK** (or push to the `main` branch).
5. When the workflow finishes, open the run and download the `Find-debug-apk` artifact.
6. Extract it and install `app-debug.apk` on an Android phone. You may need to allow installation from that file manager/browser.

This creates a debug APK for testing, not a Play Store release. The app is still a starter prototype; production backend, actual opt-in BLE advertising, secure account/chat service, moderation and privacy policy are not included.
